# Manfare Public Layout + Interaction Audit

Captured pages: 8
Errors: 0
Same-origin JS/CSS asset records: 138
Keyword matches in downloaded bundles/styles: 250

## What this report can tell you
- Visible layout geometry, headings, images, interactive elements, and fixed/sticky controls.
- Before/after states and observed fetch/XHR URL + status changes after selected clicks.
- Same-origin JS/CSS file names and keyword contexts that may help locate cart/drawer/nav logic.
- Screenshots for desktop and mobile plus after-interaction states.

## Important limitations
- Minified public JavaScript is not the original developer source; original source maps may not be published.
- Runtime observations show behavior, not a perfect reconstruction of the original internal code.
- Only one Add to Cart control is clicked at most, on the public homepage. Checkout/payment/order buttons are never clicked.
- Do not copy the site's proprietary source/assets into your project; reimplement the observed behavior in your own components.

## Pages
- https://manfarebd.com/ — manfare-interaction-audit/pages/01-home
- https://manfarebd.com/category/old-money-shirt — manfare-interaction-audit/pages/02-category-old-money-shirt
- https://manfarebd.com/category/polo-shirt — manfare-interaction-audit/pages/03-category-polo-shirt
- https://manfarebd.com/category/panjabi — manfare-interaction-audit/pages/04-category-panjabi
- https://manfarebd.com/category/drop-shoulder-tshirt — manfare-interaction-audit/pages/05-category-drop-shoulder-tshirt
- https://manfarebd.com/best_selling_product — manfare-interaction-audit/pages/06-best_selling_product
- https://manfarebd.com/new_arrival — manfare-interaction-audit/pages/07-new_arrival
- https://manfarebd.com/loyalty_program — manfare-interaction-audit/pages/08-loyalty_program