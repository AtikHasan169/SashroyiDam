Title: Manfare | Revolutionizing Men's Fashion Since 2017

URL Source: https://manfarebd.com/

Published Time: Wed, 21 Oct 2026 08:48:00 GMT

Markdown Content:
![Image 1: menu icon](https://manfarebd.com/_next/static/media/menu-bar.11f1d03e.png)

[![Image 2: manfare logo](https://manfarebd.com/_next/static/media/logo.11838dda.png)](https://manfarebd.com/)

![Image 3: contact icon](https://manfarebd.com/_next/static/media/profile-icon.616a146c.png)

[![Image 4: manfare logo](https://manfarebd.com/_next/static/media/logo.11838dda.png)](https://manfarebd.com/)

[![Image 5: contact icon](https://manfarebd.com/_next/static/media/contact-us.f7909e90.png)](tel:+8809606999695)![Image 6: wishlist icon](https://manfarebd.com/_next/static/media/wishlist-icon.8cdfcb3a.png)0![Image 7: contact icon](https://manfarebd.com/_next/static/media/profile-icon.616a146c.png)

![Image 8](https://manfarebd.com/_next/static/media/rectangle.a9cd1050.png)

*   [Home](https://manfarebd.com/)
*   [PANJABI](https://manfarebd.com/category/panjabi)
*   
[SHIRT](https://manfarebd.com/category/shirt) 
    *   [Old Money Shirt](https://manfarebd.com/category/old-money-shirt)
    *   [Remi Cotton Shirt](https://manfarebd.com/category/remi-cotton-shirt)
    *   [Half Sleeve Shirt](https://manfarebd.com/category/half-sleeve-shirt)
    *   [Casual Print Shirt](https://manfarebd.com/category/casual-print-shirt)
    *   [Denim Shirt](https://manfarebd.com/category/denim-shirt)
    *   [Solid Shirt](https://manfarebd.com/category/solid-shirt)
    *   [Cuban Shirt](https://manfarebd.com/category/cuban-shirt)
    *   [Formal Solid Shirt](https://manfarebd.com/category/formal-solid-shirt)
    *   [Checked Shirt](https://manfarebd.com/category/checked-shirt)

*   
[POLO SHIRT](https://manfarebd.com/category/polo-shirt) 
    *   [Knitted Polo](https://manfarebd.com/category/knitted-polo)
    *   [Old Money Polo](https://manfarebd.com/category/old-money-polo)

*   
[PANT](https://manfarebd.com/category/pant) 
    *   [Bootcut Gurkha Pant](https://manfarebd.com/category/bootcut-gurkha-pant)
    *   [Formal Pant](https://manfarebd.com/category/formal-pant)
    *   [BAGGY DENIM PANT](https://manfarebd.com/category/baggy-denim-pant)

*   [BOXER](https://manfarebd.com/category/boxer)
*   
[T-SHIRT](https://manfarebd.com/category/tshirt) 
    *   [Drop Shoulder T-Shirt](https://manfarebd.com/category/drop-shoulder-tshirt)
    *   [Designer Edition T-Shirt](https://manfarebd.com/category/designer-edition-tshirt)
    *   [Sports T-Shirt](https://manfarebd.com/category/sports-tshirt)
    *   [Solid T-Shirt](https://manfarebd.com/category/solid-tshirt)

*   
[WINTER](https://manfarebd.com/category/winter) 
    *   [Denim Jacket](https://manfarebd.com/category/denim-jacket)
    *   [Half Zipper Sweater](https://manfarebd.com/category/half-zipper-sweater)
    *   [Crew Neck Sweater](https://manfarebd.com/category/crew-neck-sweater)
    *   [Turtle Neck Sweater](https://manfarebd.com/category/turtle-neck-sweater)

*   
[ACCESSORIES](https://manfarebd.com/category/accessories) 
    *   [SHOE](https://manfarebd.com/category/shoe)
    *   [Belt](https://manfarebd.com/category/belt)
    *   [Wallet](https://manfarebd.com/category/wallet)
    *   [Fashion Mask](https://manfarebd.com/category/fashion-mask)
    *   [SUMMER TRACKSUIT COMBO](https://manfarebd.com/category/summer-tracksuit-combo)
    *   [TROUSER](https://manfarebd.com/category/trouser)
    *   [Turtle Neck](https://manfarebd.com/turtle_neck_campaign)

*   
[SHOP](https://manfarebd.com/shop) 
    *   [Casual solid remi shirt](https://manfarebd.com/casual_solid_remi_shirt)
    *   [Men's Shirt](https://manfarebd.com/men's_shirt)
    *   [summer arrival](https://manfarebd.com/summer_arrival)

*   
[LIFESTYLE](https://manfarebd.com/lifestyle) 
    *   [এই ঈদে পাঞ্জাবির ট্রেন্ড কি জেনে নিন](https://manfarebd.com/%E0%A6%8F%E0%A6%87_%E0%A6%88%E0%A6%A6%E0%A7%87_%E0%A6%AA%E0%A6%BE%E0%A6%9E%E0%A7%8D%E0%A6%9C%E0%A6%BE%E0%A6%AC%E0%A6%BF%E0%A6%B0_%E0%A6%9F%E0%A7%8D%E0%A6%B0%E0%A7%87%E0%A6%A8%E0%A7%8D%E0%A6%A1_%E0%A6%95%E0%A6%BF_%E0%A6%9C%E0%A7%87%E0%A6%A8%E0%A7%87_%E0%A6%A8%E0%A6%BF%E0%A6%A8)
    *   [জেনজিদের পছন্দ ড্রপড শোল্ডার টি-শার্ট](https://manfarebd.com/%E0%A6%9C%E0%A7%87%E0%A6%A8%E0%A6%9C%E0%A6%BF%E0%A6%A6%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A6%9B%E0%A6%A8%E0%A7%8D%E0%A6%A6_%E0%A6%A1%E0%A7%8D%E0%A6%B0%E0%A6%AA%E0%A6%A1_%E0%A6%B6%E0%A7%8B%E0%A6%B2%E0%A7%8D%E0%A6%A1%E0%A6%BE%E0%A6%B0_%E0%A6%9F%E0%A6%BF-%E0%A6%B6%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%9F)
    *   [গরমে পুরুষদের প্রথম পছন্দ—আরামদায়ক পোলো শার্ট](https://manfarebd.com/%E0%A6%97%E0%A6%B0%E0%A6%AE%E0%A7%87_%E0%A6%AA%E0%A7%81%E0%A6%B0%E0%A7%81%E0%A6%B7%E0%A6%A6%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A5%E0%A6%AE_%E0%A6%AA%E0%A6%9B%E0%A6%A8%E0%A7%8D%E0%A6%A6%E2%80%94%E0%A6%86%E0%A6%B0%E0%A6%BE%E0%A6%AE%E0%A6%A6%E0%A6%BE%E0%A7%9F%E0%A6%95_%E0%A6%AA%E0%A7%8B%E0%A6%B2%E0%A7%8B_%E0%A6%B6%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%9F)
    *   [আধুনিক করপোরেট স্টাইল: পুরুষদের ফরমাল ফ্যাশনে নতুন মাত্রা](https://manfarebd.com/%E0%A6%86%E0%A6%A7%E0%A7%81%E0%A6%A8%E0%A6%BF%E0%A6%95_%E0%A6%95%E0%A6%B0%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%87%E0%A6%9F_%E0%A6%B8%E0%A7%8D%E0%A6%9F%E0%A6%BE%E0%A6%87%E0%A6%B2:_%E0%A6%AA%E0%A7%81%E0%A6%B0%E0%A7%81%E0%A6%B7%E0%A6%A6%E0%A7%87%E0%A6%B0_%E0%A6%AB%E0%A6%B0%E0%A6%AE%E0%A6%BE%E0%A6%B2_%E0%A6%AB%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%B6%E0%A6%A8%E0%A7%87_%E0%A6%A8%E0%A6%A4%E0%A7%81%E0%A6%A8_%E0%A6%AE%E0%A6%BE%E0%A6%A4%E0%A7%8D%E0%A6%B0%E0%A6%BE)
    *   [গ্রীষ্মে স্টাইল ও আরামের সমন্বয়: জনপ্রিয়তায় কিউবান কলার শার্ট](https://manfarebd.com/%E0%A6%97%E0%A7%8D%E0%A6%B0%E0%A7%80%E0%A6%B7%E0%A7%8D%E0%A6%AE%E0%A7%87_%E0%A6%B8%E0%A7%8D%E0%A6%9F%E0%A6%BE%E0%A6%87%E0%A6%B2_%E0%A6%93_%E0%A6%86%E0%A6%B0%E0%A6%BE%E0%A6%AE%E0%A7%87%E0%A6%B0_%E0%A6%B8%E0%A6%AE%E0%A6%A8%E0%A7%8D%E0%A6%AC%E0%A7%9F:_%E0%A6%9C%E0%A6%A8%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%BF%E0%A7%9F%E0%A6%A4%E0%A6%BE%E0%A7%9F_%E0%A6%95%E0%A6%BF%E0%A6%89%E0%A6%AC%E0%A6%BE%E0%A6%A8_%E0%A6%95%E0%A6%B2%E0%A6%BE%E0%A6%B0_%E0%A6%B6%E0%A6%BE%E0%A6%B0%E0%A7%8D%E0%A6%9F)
    *   [new casual print shirt](https://manfarebd.com/new_casual_print_shirt)
    *   [ঈদের আনন্দে নতুনত্বের ছোঁয়া: বিভিন্ন ডিজাইনের পাঞ্জাবি নিয়ে এসেছে ম্যানফেয়ার](https://manfarebd.com/%E0%A6%88%E0%A6%A6%E0%A7%87%E0%A6%B0_%E0%A6%86%E0%A6%A8%E0%A6%A8%E0%A7%8D%E0%A6%A6%E0%A7%87_%E0%A6%A8%E0%A6%A4%E0%A7%81%E0%A6%A8%E0%A6%A4%E0%A7%8D%E0%A6%AC%E0%A7%87%E0%A6%B0_%E0%A6%9B%E0%A7%8B%E0%A6%81%E0%A7%9F%E0%A6%BE:_%E0%A6%AC%E0%A6%BF%E0%A6%AD%E0%A6%BF%E0%A6%A8%E0%A7%8D%E0%A6%A8_%E0%A6%A1%E0%A6%BF%E0%A6%9C%E0%A6%BE%E0%A6%87%E0%A6%A8%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A6%BE%E0%A6%9E%E0%A7%8D%E0%A6%9C%E0%A6%BE%E0%A6%AC%E0%A6%BF_%E0%A6%A8%E0%A6%BF%E0%A7%9F%E0%A7%87_%E0%A6%8F%E0%A6%B8%E0%A7%87%E0%A6%9B%E0%A7%87_%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%E0%A6%AB%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0)
    *   [একটু যত্নে বেছে নিন বেল্ট—আপনার ব্যক্তিত্বের পরিচয় ওখানেই](https://manfarebd.com/%E0%A6%8F%E0%A6%95%E0%A6%9F%E0%A7%81_%E0%A6%AF%E0%A6%A4%E0%A7%8D%E0%A6%A8%E0%A7%87_%E0%A6%AC%E0%A7%87%E0%A6%9B%E0%A7%87_%E0%A6%A8%E0%A6%BF%E0%A6%A8_%E0%A6%AC%E0%A7%87%E0%A6%B2%E0%A7%8D%E0%A6%9F%E2%80%94%E0%A6%86%E0%A6%AA%E0%A6%A8%E0%A6%BE%E0%A6%B0_%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF%E0%A6%A4%E0%A7%8D%E0%A6%AC%E0%A7%87%E0%A6%B0_%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A7%9F_%E0%A6%93%E0%A6%96%E0%A6%BE%E0%A6%A8%E0%A7%87%E0%A6%87)

![Image 9: shopping icon](https://manfarebd.com/_next/static/media/shopping-icon.ce9b4cf2.png)
0 items

0

[![Image 10: slide image](https://static.bitcommerz.com/manfarebd/media/178748463709674435266_cover_new_shirt.webp)](https://manfarebd.com/category/old-money-striped-shirt)

[![Image 11: slide image](https://static.bitcommerz.com/manfarebd/media/177798829275254222196_old_moyae_polo_web_.webp)](https://manfarebd.com/category/knitted-polo)

[![Image 12: slide image](https://static.bitcommerz.com/manfarebd/media/177798830025681881369_gurkha_web_cover.webp)](https://manfarebd.com/category/bootcut-gurkha-pant)

[![Image 13: slide image](https://static.bitcommerz.com/manfarebd/media/177798829682249474191_half_shirt_web_cover.webp)](https://manfarebd.com/category/half-sleeve-shirt)

[![Image 14: slide image](https://static.bitcommerz.com/manfarebd/media/175916680605718166150_bagge_web_cover_1.webp)](https://manfarebd.com/category/drop-shoulder-tshirt)

[![Image 15: slide image](https://static.bitcommerz.com/manfarebd/media/177894709301645357468_cover_2.webp)](https://manfarebd.com/category/panjabi)

[![Image 16: slide image](https://static.bitcommerz.com/manfarebd/media/177186171663757534767_loyality_card_copy.webp)](https://manfarebd.com/loyalty_program)

![Image 17: delivery icon](https://manfarebd.com/_next/static/media/Fastest-Shipping.efdae6a0.svg)

![Image 18: delivery icon](https://manfarebd.com/_next/static/media/Easy-Return-Policy.247734ff.svg)

![Image 19: delivery icon](https://manfarebd.com/_next/static/media/Premium-Qualiy-Product.220aaabd.svg)

![Image 20: delivery icon](https://manfarebd.com/_next/static/media/Online-Support-24-7.a66f7a77.svg)

## browse our categories

## browse our categories

[](https://manfarebd.com/)

* * *

[![Image 21: category img](https://static.bitcommerz.com/manfarebd/media/sm/178835721769576000852_web_card_old_money_shirtjpg.webp)](https://manfarebd.com/category/old-money-shirt)[OLD MONEY SHIRT](https://manfarebd.com/category/old-money-shirt)

[![Image 22: category img](https://static.bitcommerz.com/manfarebd/media/sm/178844253362964651143_web_card_solid_shirt.webp)](https://manfarebd.com/category/remi-cotton-shirt)[REMI COTTON SHIRT](https://manfarebd.com/category/remi-cotton-shirt)

[![Image 23: category img](https://static.bitcommerz.com/manfarebd/media/sm/177799451597618912378_category_cards_knitted_polo.webp)](https://manfarebd.com/category/polo-shirt)[POLO SHIRT](https://manfarebd.com/category/polo-shirt)

[![Image 24: category img](https://static.bitcommerz.com/manfarebd/media/sm/177799453966527468424_category_cards_gurkha_pant.webp)](https://manfarebd.com/category/bootcut-gurkha-pant)[BOOTCUT FORMAL PANT](https://manfarebd.com/category/bootcut-gurkha-pant)

[![Image 25: category img](https://static.bitcommerz.com/manfarebd/media/sm/177799448192420972676_category_cards_panjabi.webp)](https://manfarebd.com/category/panjabi)[PANJABI](https://manfarebd.com/category/panjabi)

[![Image 26: category img](https://static.bitcommerz.com/manfarebd/media/sm/177799449231732765375_category_cards_half_shirt.webp)](https://manfarebd.com/category/shirt)[HALF SHIRT](https://manfarebd.com/category/shirt)

[![Image 27: category img](https://static.bitcommerz.com/manfarebd/media/sm/176581748811188152344_5_web_card_drop.webp)](https://manfarebd.com/category/drop-shoulder-tshirt)[DROP SHOULDER T-SHIRT](https://manfarebd.com/category/drop-shoulder-tshirt)

[![Image 28: category img](https://static.bitcommerz.com/manfarebd/media/sm/176581749460025076532_7_web_card_wallet.webp)](https://manfarebd.com/category/wallet)[WALLET](https://manfarebd.com/category/wallet)

[![Image 29: category img](https://static.bitcommerz.com/manfarebd/media/sm/176581750101679457971_9_web_card_belt_1.webp)](https://manfarebd.com/category/belt)[BELT](https://manfarebd.com/category/belt)

## Best Selling Products

[View All](https://manfarebd.com/best_selling_product)

## Best Selling Products

[View All](https://manfarebd.com/best_selling_product)

* * *

[![Image 30: Premium Remi Cotton Shirt | Brown | MS-256](https://static.bitcommerz.com/manfarebd/media/md/178868847946321105085_ms_256_1.webp)](https://manfarebd.com/product/premium-remi-cotton-shirt-brown-ms256)
0.0 | 0.0

### [Premium Remi Cotton Shirt | Brown | MS-256](https://manfarebd.com/product/premium-remi-cotton-shirt-brown-ms256)
TK. 990 TK. 1500

Add To Cart

[![Image 31: Mint and blue Old Money Striped Check Shirt | MS-264](https://static.bitcommerz.com/manfarebd/media/md/178801726994729549151_ms_264_1.webp)](https://manfarebd.com/product/mint-and-blue-old-money-striped-shirt-ms264)
0.0 | 0.0

### [Mint and blue Old Money Striped Check Shirt | MS-264](https://manfarebd.com/product/mint-and-blue-old-money-striped-shirt-ms264)
TK. 1190 TK. 1500

Add To Cart

[![Image 32: Rosy Brown and White Old Money Striped Shirt | MS-261](https://static.bitcommerz.com/manfarebd/media/md/178868648361148431113_ms_261_1_2.webp)](https://manfarebd.com/product/rosy-brown-and-white-old-money-striped-shirt-ms261)
0.0 | 0.0

### [Rosy Brown and White Old Money Striped Shirt | MS-261](https://manfarebd.com/product/rosy-brown-and-white-old-money-striped-shirt-ms261)
TK. 1190 TK. 1500

Add To Cart

[![Image 33: Men Pink and White Old Money Striped Shirt | MS-240](https://static.bitcommerz.com/manfarebd/media/md/178577819224898680080_ms_240_1.webp)](https://manfarebd.com/product/men-pink-and-white-old-money-striped-shirt-ms248)
0.0 | 0.0

### [Men Pink and White Old Money Striped Shirt | MS-240](https://manfarebd.com/product/men-pink-and-white-old-money-striped-shirt-ms248)
TK. 1190 TK. 1500

Add To Cart

[![Image 34: White and Blue Old Money Striped Shirt | MS-247](https://static.bitcommerz.com/manfarebd/media/md/178577746448511839721_ms_247_1.webp)](https://manfarebd.com/product/white-and-blue-old-money-striped-shirt-ms247)
0.0 | 0.0

### [White and Blue Old Money Striped Shirt | MS-247](https://manfarebd.com/product/white-and-blue-old-money-striped-shirt-ms247)
TK. 1190 TK. 1500

Add To Cart

[![Image 35: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-29](https://static.bitcommerz.com/manfarebd/media/md/178775469484925761540_mpant_291.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant29)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-29](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant29)
TK. 1190 TK. 1490

Add To Cart

[![Image 36: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-25](https://static.bitcommerz.com/manfarebd/media/md/178482145576449292185_mpant_25.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant25)
5.0 | 01

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-25](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant25)
TK. 1190 TK. 1490

Add To Cart

[![Image 37: Brown and Off White Old Money Striped Shirt | MS-246](https://static.bitcommerz.com/manfarebd/media/md/178577765523075421755_ms_246_1.webp)](https://manfarebd.com/product/brown-and-off-white-old-money-striped-shirt-ms246)
0.0 | 0.0

### [Brown and Off White Old Money Striped Shirt | MS-246](https://manfarebd.com/product/brown-and-off-white-old-money-striped-shirt-ms246)
TK. 1190 TK. 1500

Add To Cart

[![Image 38: Multicolor Remi Cotton Old Money Striped Shirt | MS-229](https://static.bitcommerz.com/manfarebd/media/md/178577933860766314100_ms_229_1.webp)](https://manfarebd.com/product/multicolor-remi-cotton-old-money-striped-shirt-ms229)
0.0 | 0.0

### [Multicolor Remi Cotton Old Money Striped Shirt | MS-229](https://manfarebd.com/product/multicolor-remi-cotton-old-money-striped-shirt-ms229)
TK. 1190 TK. 1500

Add To Cart

[![Image 39: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-704](https://static.bitcommerz.com/manfarebd/media/md/175914877895358334156_mf_704_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf704)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-704](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf704)
TK. 650

Add To Cart

[![Image 40: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://static.bitcommerz.com/manfarebd/media/md/178775483256923623825_mpant_27_1.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
TK. 1190 TK. 1490

Add To Cart

[![Image 41: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://static.bitcommerz.com/manfarebd/media/md/178482143297117972281_mpant_24.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
TK. 1190 TK. 1490

Add To Cart

[![Image 42: Faded Olive and White Remi Old Money Striped Shirt | MS-245](https://static.bitcommerz.com/manfarebd/media/md/178577774514123625518_ms_245_1.webp)](https://manfarebd.com/product/faded-olive-and-white-remi-old-money-striped-shirt-ms245)
0.0 | 0.0

### [Faded Olive and White Remi Old Money Striped Shirt | MS-245](https://manfarebd.com/product/faded-olive-and-white-remi-old-money-striped-shirt-ms245)
TK. 1190 TK. 1500

Add To Cart

[![Image 43: Off White and Green Old Money Striped Shirt | MS-248](https://static.bitcommerz.com/manfarebd/media/md/178577613779266243468_ms_248_1.webp)](https://manfarebd.com/product/off-white-and-green-old-money-striped-shirt-ms248)
0.0 | 0.0

### [Off White and Green Old Money Striped Shirt | MS-248](https://manfarebd.com/product/off-white-and-green-old-money-striped-shirt-ms248)
TK. 1190 TK. 1500

Add To Cart

[![Image 44: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-720](https://static.bitcommerz.com/manfarebd/media/md/175915208258595628550_mf_720_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf720)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-720](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf720)
TK. 650

Add To Cart

[![Image 45: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-708](https://static.bitcommerz.com/manfarebd/media/md/175914938965811656371_mf_708_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf708)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-708](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf708)
TK. 650

Add To Cart

[![Image 46: Half Sleeve Printed Casual Shirt For Men | MS-210](https://static.bitcommerz.com/manfarebd/media/md/177738906055579092966_ms_210.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms210)
4.5 | 02

### [Half Sleeve Printed Casual Shirt For Men | MS-210](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms210)
TK. 749 TK. 1500

Add To Cart

[![Image 47: Half Sleeve Printed Casual Shirt For Men | MS-224](https://static.bitcommerz.com/manfarebd/media/md/177781831772949425692_ms_224_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms224)
5.0 | 01

### [Half Sleeve Printed Casual Shirt For Men | MS-224](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms224)
TK. 749 TK. 1500

Add To Cart

[![Image 48: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-717](https://static.bitcommerz.com/manfarebd/media/md/175915153438978731066_mf_717_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf717)
5.0 | 02

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-717](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf717)
TK. 650

Add To Cart

[![Image 49: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-700](https://static.bitcommerz.com/manfarebd/media/md/175914741033146033399_mf_700_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf700)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-700](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf700)
TK. 650

Add To Cart

[![Image 50: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-701](https://static.bitcommerz.com/manfarebd/media/md/175914763837385998834_mf_701_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf701)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-701](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf701)
TK. 650

Add To Cart

[![Image 51: Half Sleeve Printed Casual Shirt For Men | MS-194](https://static.bitcommerz.com/manfarebd/media/md/177781676178691219307_ms_194_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms194)
5.0 | 01

### [Half Sleeve Printed Casual Shirt For Men | MS-194](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms194)
TK. 749 TK. 1500

Add To Cart

[![Image 52: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://static.bitcommerz.com/manfarebd/media/md/178482150335922417188_mpant_26.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
TK. 1190 TK. 1490

Add To Cart

[![Image 53: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-716](https://static.bitcommerz.com/manfarebd/media/md/175915135532844357337_mf_716_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf716)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-716](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf716)
TK. 650

Add To Cart

[![Image 54: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-703](https://static.bitcommerz.com/manfarebd/media/md/175914849051041567257_mf_703_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf703)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-703](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf703)
TK. 650

Add To Cart

[![Image 55: Half Sleeve Printed Casual Shirt For Men | MS-219](https://static.bitcommerz.com/manfarebd/media/md/177798565974822876382_ms_219_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms219)
3.7 | 03

### [Half Sleeve Printed Casual Shirt For Men | MS-219](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms219)
TK. 749 TK. 1500

Add To Cart

[![Image 56: Half Sleeve Printed Casual Shirt For Men | MS-196](https://static.bitcommerz.com/manfarebd/media/md/177738905080734038377_ms_196.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms196)
5.0 | 01

### [Half Sleeve Printed Casual Shirt For Men | MS-196](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms196)
TK. 749 TK. 1500

Add To Cart

[![Image 57: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://static.bitcommerz.com/manfarebd/media/md/178482156219278808796_mpant_28.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
TK. 1190 TK. 1490

Add To Cart

[![Image 58: Premium Knitted Polo Shirt For Men | MFP-51](https://static.bitcommerz.com/manfarebd/media/md/177780792692689636352_mfp_51_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp51)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-51](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp51)
TK. 1190 TK. 1500

Add To Cart

[![Image 59: Premium Knitted Polo Shirt For Men | MFP-52](https://static.bitcommerz.com/manfarebd/media/md/177780781868242202997_mfp_52_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp52)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-52](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp52)
TK. 1190 TK. 1500

Add To Cart

[![Image 60: Half Sleeve Printed Casual Shirt For Men | MS-225](https://static.bitcommerz.com/manfarebd/media/md/177781710366771076571_ms_225_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms225)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-225](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms225)
TK. 749 TK. 1500

Add To Cart

[![Image 61: Half Sleeve Printed Casual Shirt For Men | MS-212](https://static.bitcommerz.com/manfarebd/media/md/177781785849425805670_ms_212_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms212)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-212](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms212)
TK. 749 TK. 1500

Add To Cart

## New Arrival Products

[See All](https://manfarebd.com/new_arrival)

## New Arrival Products

[See All](https://manfarebd.com/new_arrival)

* * *

[![Image 62: Multicolor Old Money Striped Shirt | MS-272](https://static.bitcommerz.com/manfarebd/media/md/178801958575650498434_ms_272_1.webp)](https://manfarebd.com/product/multicolor-old-money-striped-shirt-ms272)
0.0 | 0.0

### [Multicolor Old Money Striped Shirt | MS-272](https://manfarebd.com/product/multicolor-old-money-striped-shirt-ms272)
TK. 1190 TK. 1500

Add To Cart

[![Image 63: Sky blue and White Old Money Striped Shirt | MS-259](https://static.bitcommerz.com/manfarebd/media/md/178868663437767377431_ms_259_1_2.webp)](https://manfarebd.com/product/sky-blue-and-white-old-money-striped-shirt-ms259)
0.0 | 0.0

### [Sky blue and White Old Money Striped Shirt | MS-259](https://manfarebd.com/product/sky-blue-and-white-old-money-striped-shirt-ms259)
TK. 1190 TK. 1500

Add To Cart

[![Image 64: Mint and blue Old Money Striped Check Shirt | MS-264](https://static.bitcommerz.com/manfarebd/media/md/178801726994729549151_ms_264_1.webp)](https://manfarebd.com/product/mint-and-blue-old-money-striped-shirt-ms264)
0.0 | 0.0

### [Mint and blue Old Money Striped Check Shirt | MS-264](https://manfarebd.com/product/mint-and-blue-old-money-striped-shirt-ms264)
TK. 1190 TK. 1500

Add To Cart

[![Image 65: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-29](https://static.bitcommerz.com/manfarebd/media/md/178775469484925761540_mpant_291.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant29)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-29](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant29)
TK. 1190 TK. 1490

Add To Cart

[![Image 66: Multicolor Remi Cotton Old Money Striped Shirt | MS-229](https://static.bitcommerz.com/manfarebd/media/md/178577933860766314100_ms_229_1.webp)](https://manfarebd.com/product/multicolor-remi-cotton-old-money-striped-shirt-ms229)
0.0 | 0.0

### [Multicolor Remi Cotton Old Money Striped Shirt | MS-229](https://manfarebd.com/product/multicolor-remi-cotton-old-money-striped-shirt-ms229)
TK. 1190 TK. 1500

Add To Cart

[![Image 67: Off White and Green Old Money Striped Shirt | MS-248](https://static.bitcommerz.com/manfarebd/media/md/178577613779266243468_ms_248_1.webp)](https://manfarebd.com/product/off-white-and-green-old-money-striped-shirt-ms248)
0.0 | 0.0

### [Off White and Green Old Money Striped Shirt | MS-248](https://manfarebd.com/product/off-white-and-green-old-money-striped-shirt-ms248)
TK. 1190 TK. 1500

Add To Cart

[![Image 68: White and Blue Old Money Striped Shirt | MS-247](https://static.bitcommerz.com/manfarebd/media/md/178577746448511839721_ms_247_1.webp)](https://manfarebd.com/product/white-and-blue-old-money-striped-shirt-ms247)
0.0 | 0.0

### [White and Blue Old Money Striped Shirt | MS-247](https://manfarebd.com/product/white-and-blue-old-money-striped-shirt-ms247)
TK. 1190 TK. 1500

Add To Cart

[![Image 69: Brown and Off White Old Money Striped Shirt | MS-246](https://static.bitcommerz.com/manfarebd/media/md/178577765523075421755_ms_246_1.webp)](https://manfarebd.com/product/brown-and-off-white-old-money-striped-shirt-ms246)
0.0 | 0.0

### [Brown and Off White Old Money Striped Shirt | MS-246](https://manfarebd.com/product/brown-and-off-white-old-money-striped-shirt-ms246)
TK. 1190 TK. 1500

Add To Cart

[![Image 70: Men Pink and White Old Money Striped Shirt | MS-240](https://static.bitcommerz.com/manfarebd/media/md/178577819224898680080_ms_240_1.webp)](https://manfarebd.com/product/men-pink-and-white-old-money-striped-shirt-ms248)
0.0 | 0.0

### [Men Pink and White Old Money Striped Shirt | MS-240](https://manfarebd.com/product/men-pink-and-white-old-money-striped-shirt-ms248)
TK. 1190 TK. 1500

Add To Cart

[![Image 71: Light Olive and White Remi Cotton Old Money Striped Shirt | MS-241](https://static.bitcommerz.com/manfarebd/media/md/178577810989228422583_ms_241_1.webp)](https://manfarebd.com/product/light-olive-and-white-remi-cotton-old-money-striped-shirt-ms241)
0.0 | 0.0

### [Light Olive and White Remi Cotton Old Money Striped Shirt | MS-241](https://manfarebd.com/product/light-olive-and-white-remi-cotton-old-money-striped-shirt-ms241)
TK. 1190 TK. 1500

Add To Cart

[![Image 72: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-726](https://static.bitcommerz.com/manfarebd/media/md/177894595293181932109_mf_726_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf726)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-726](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf726)
TK. 650

Add To Cart

[![Image 73: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-725](https://static.bitcommerz.com/manfarebd/media/md/177894585624755861083_mf_725_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf725)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-725](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf725)
TK. 650

Add To Cart

[![Image 74: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-724](https://static.bitcommerz.com/manfarebd/media/md/177894569697859619330_mf_724_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf724)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-724](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf724)
TK. 650

Add To Cart

[![Image 75: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-723](https://static.bitcommerz.com/manfarebd/media/md/177894545068960703024_mf_723_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf723)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-723](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf723)
TK. 650

Add To Cart

[![Image 76: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-722](https://static.bitcommerz.com/manfarebd/media/md/177894524589667691357_mf_722_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf722)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-722](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf722)
TK. 650

Add To Cart

[![Image 77: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-721](https://static.bitcommerz.com/manfarebd/media/md/177894508550780168165_mf_721_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf721)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-721](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf721)
TK. 650

Add To Cart

[![Image 78: Half Sleeve Printed Casual Shirt For Men | MS-211](https://static.bitcommerz.com/manfarebd/media/md/177738906140730155889_ms_211.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms211)
5.0 | 03

### [Half Sleeve Printed Casual Shirt For Men | MS-211](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms211)
TK. 749 TK. 1500

Add To Cart

[![Image 79: Half Sleeve Printed Casual Shirt For Men | MS-202](https://static.bitcommerz.com/manfarebd/media/md/177738905586780974899_ms_202.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms202)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-202](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms202)
TK. 749 TK. 1500

Add To Cart

[![Image 80: Premium Knitted Polo Shirt For Men | MFP-53](https://static.bitcommerz.com/manfarebd/media/md/177780770261955712850_mfp_53_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp53)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-53](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp53)
TK. 1190 TK. 1500

Add To Cart

[![Image 81: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://static.bitcommerz.com/manfarebd/media/md/178482150335922417188_mpant_26.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
TK. 1190 TK. 1490

Add To Cart

[![Image 82: Half Sleeve Printed Casual Shirt For Men | MS-206](https://static.bitcommerz.com/manfarebd/media/md/177738905876967391949_ms_206.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms206)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-206](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms206)
TK. 749 TK. 1500

Add To Cart

[![Image 83: Half Sleeve Printed Casual Shirt For Men | MS-217](https://static.bitcommerz.com/manfarebd/media/md/177781690060469048970_ms_217_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms217)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-217](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms217)
TK. 749 TK. 1500

Add To Cart

[![Image 84: Premium Knitted Polo Shirt For Men | MFP-56](https://static.bitcommerz.com/manfarebd/media/md/177780718942954800804_mfp_56_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp56)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-56](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp56)
TK. 1190 TK. 1500

Add To Cart

[![Image 85: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://static.bitcommerz.com/manfarebd/media/md/178775483256923623825_mpant_27_1.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
TK. 1190 TK. 1490

Add To Cart

[![Image 86: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://static.bitcommerz.com/manfarebd/media/md/178482156219278808796_mpant_28.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
TK. 1190 TK. 1490

Add To Cart

[![Image 87: Half Sleeve Printed Casual Shirt For Men | MS-215](https://static.bitcommerz.com/manfarebd/media/md/177781685713061104552_ms_215_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms215)
0.0 | 0.0

### [Half Sleeve Printed Casual Shirt For Men | MS-215](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms215)
TK. 749 TK. 1500

Add To Cart

[![Image 88: Half Sleeve Printed Casual Shirt For Men | MS-200](https://static.bitcommerz.com/manfarebd/media/md/177781680708650380017_ms_200_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms200)
5.0 | 01

### [Half Sleeve Printed Casual Shirt For Men | MS-200](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms200)
TK. 749 TK. 1500

Add To Cart

[![Image 89: Half Sleeve Printed Casual Shirt For Men | MS-201](https://static.bitcommerz.com/manfarebd/media/md/177798528662663236076_ms_201_1.webp)](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms201)
3.0 | 01

### [Half Sleeve Printed Casual Shirt For Men | MS-201](https://manfarebd.com/product/half-sleeve-printed-casual-shirt-for-men-ms201)
TK. 749 TK. 1500

Add To Cart

[![Image 90: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://static.bitcommerz.com/manfarebd/media/md/178482143297117972281_mpant_24.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
TK. 1190 TK. 1490

Add To Cart

# Manfare Eid Collection 2026

[Video 1](https://www.youtube.com/watch?v=GQYxiTsBe6E)

# KNITTED POLO

[Video 2](https://www.youtube.com/watch?v=sxOsXCj9eq8)

[![Image 91: slide image](https://static.bitcommerz.com/manfarebd/media/178869861791636863819_web_banner.webp)](https://manfarebd.com/)

[![Image 92: Premium Remi Cotton Shirt | Cream | MS-255](https://static.bitcommerz.com/manfarebd/media/md/178868842435881997740_ms_255_1.webp)](https://manfarebd.com/product/premium-remi-cotton-shirt-cream-ms255)
0.0 | 0.0

### [Premium Remi Cotton Shirt | Cream | MS-255](https://manfarebd.com/product/premium-remi-cotton-shirt-cream-ms255)
TK. 990 TK. 1500

Add To Cart

[![Image 93: Premium Remi Cotton Shirt | Brown | MS-256](https://static.bitcommerz.com/manfarebd/media/md/178868847946321105085_ms_256_1.webp)](https://manfarebd.com/product/premium-remi-cotton-shirt-brown-ms256)
0.0 | 0.0

### [Premium Remi Cotton Shirt | Brown | MS-256](https://manfarebd.com/product/premium-remi-cotton-shirt-brown-ms256)
TK. 990 TK. 1500

Add To Cart

![Image 94: manfare logo](https://manfarebd.com/_next/static/media/about-manfare.941847ad.png)

[![Image 95: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/md/177159452640628470149_product_caruosel_banner_panjabi.webp)](https://manfarebd.com/category/panjabi)[![Image 96: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/177159452640628470149_product_caruosel_banner_panjabi.webp)](https://manfarebd.com/category/panjabi)

[![Image 97: Manfare ELITE Quality Panjabi I MP-282](https://static.bitcommerz.com/manfarebd/media/md/177860976149460810546_mp_282_1.webp)](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp282)
0.0 | 0.0

### [Manfare ELITE Quality Panjabi I MP-282](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp282)
TK. 2990 TK. 3750

Add To Cart

[![Image 98: Manfare ELITE Quality Panjabi I MP-255](https://static.bitcommerz.com/manfarebd/media/md/177860933514087267560_mp_255_1.webp)](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp255)
0.0 | 0.0

### [Manfare ELITE Quality Panjabi I MP-255](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp255)
TK. 2990 TK. 3750

Add To Cart

[![Image 99: Manfare ELITE Quality Panjabi I MP-251](https://static.bitcommerz.com/manfarebd/media/md/177860926905998766351_mp_251_1.webp)](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp251)
0.0 | 0.0

### [Manfare ELITE Quality Panjabi I MP-251](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp251)
TK. 2990 TK. 3750

Add To Cart

[![Image 100: Manfare ELITE Quality Panjabi I MP-244](https://static.bitcommerz.com/manfarebd/media/md/177860922883380005254_mp_244_1.webp)](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp244)
0.0 | 0.0

### [Manfare ELITE Quality Panjabi I MP-244](https://manfarebd.com/product/manfare-elite-quality-panjabi-i-mp244)
TK. 2990 TK. 3750

Add To Cart

[![Image 101: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/md/177799054199940989123_product_caruosel_banner_premium_tshirt.webp)](https://manfarebd.com/category/bootcut-gurkha-pant)[![Image 102: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/177799054199940989123_product_caruosel_banner_premium_tshirt.webp)](https://manfarebd.com/category/bootcut-gurkha-pant)

[![Image 103: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://static.bitcommerz.com/manfarebd/media/md/178482143297117972281_mpant_24.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-24](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant24)
TK. 1190 TK. 1490

Add To Cart

[![Image 104: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-25](https://static.bitcommerz.com/manfarebd/media/md/178482145576449292185_mpant_25.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant25)
5.0 | 01

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-25](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant25)
TK. 1190 TK. 1490

Add To Cart

[![Image 105: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://static.bitcommerz.com/manfarebd/media/md/178482150335922417188_mpant_26.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-26](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant26)
TK. 1190 TK. 1490

Add To Cart

[![Image 106: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://static.bitcommerz.com/manfarebd/media/md/178775483256923623825_mpant_27_1.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-27](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant27)
TK. 1190 TK. 1490

Add To Cart

[![Image 107: Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://static.bitcommerz.com/manfarebd/media/md/178482156219278808796_mpant_28.webp)](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
0.0 | 0.0

### [Premium Formal BOOTCUT GURKHA PANT For Men | MPANT-28](https://manfarebd.com/product/premium-formal-bootcut-gurkha-pant-for-men-mpant28)
TK. 1190 TK. 1490

Add To Cart

[![Image 108](https://static.bitcommerz.com/manfarebd/media/lg/1727359377169-manfarebd-id-13.webp)](https://manfarebd.com/category/polo-shirt)

[![Image 109](https://static.bitcommerz.com/manfarebd/media/md/1727359384503-manfarebd-id-13.webp)](https://manfarebd.com/category/boxer)[![Image 110](https://static.bitcommerz.com/manfarebd/media/md/1727359392087-manfarebd-id-13.webp)](https://manfarebd.com/category/designer-edition-tshirt)

[![Image 111: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/md/177799068601889121541_product_caruosel_banner_polo_shirt.webp)](https://manfarebd.com/category/knitted-polo)[![Image 112: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/177799068601889121541_product_caruosel_banner_polo_shirt.webp)](https://manfarebd.com/category/knitted-polo)

[![Image 113: Premium Knitted Polo Shirt For Men | MFP-51](https://static.bitcommerz.com/manfarebd/media/md/177780792692689636352_mfp_51_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp51)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-51](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp51)
TK. 1190 TK. 1500

Add To Cart

[![Image 114: Premium Knitted Polo Shirt For Men | MFP-52](https://static.bitcommerz.com/manfarebd/media/md/177780781868242202997_mfp_52_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp52)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-52](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp52)
TK. 1190 TK. 1500

Add To Cart

[![Image 115: Premium Knitted Polo Shirt For Men | MFP-53](https://static.bitcommerz.com/manfarebd/media/md/177780770261955712850_mfp_53_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp53)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-53](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp53)
TK. 1190 TK. 1500

Add To Cart

[![Image 116: Premium Knitted Polo Shirt For Men | MFP-56](https://static.bitcommerz.com/manfarebd/media/md/177780718942954800804_mfp_56_1.webp)](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp56)
0.0 | 0.0

### [Premium Knitted Polo Shirt For Men | MFP-56](https://manfarebd.com/product/premium-knitted-polo-shirt-for-men-mfp56)
TK. 1190 TK. 1500

Add To Cart

[![Image 117: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/md/174500259077724501444_product_caruosel_banner_drop_shoulder_t_shirt.webp)](https://manfarebd.com/category/drop-shoulder-tshirt)[![Image 118: sleeve t-shirt](https://static.bitcommerz.com/manfarebd/media/174500259077724501444_product_caruosel_banner_drop_shoulder_t_shirt.webp)](https://manfarebd.com/category/drop-shoulder-tshirt)

[![Image 119: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-726](https://static.bitcommerz.com/manfarebd/media/md/177894595293181932109_mf_726_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf726)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-726](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf726)
TK. 650

Add To Cart

[![Image 120: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-725](https://static.bitcommerz.com/manfarebd/media/md/177894585624755861083_mf_725_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf725)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-725](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf725)
TK. 650

Add To Cart

[![Image 121: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-724](https://static.bitcommerz.com/manfarebd/media/md/177894569697859619330_mf_724_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf724)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-724](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf724)
TK. 650

Add To Cart

[![Image 122: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-723](https://static.bitcommerz.com/manfarebd/media/md/177894545068960703024_mf_723_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf723)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-723](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf723)
TK. 650

Add To Cart

[![Image 123: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-722](https://static.bitcommerz.com/manfarebd/media/md/177894524589667691357_mf_722_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf722)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-722](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf722)
TK. 650

Add To Cart

[![Image 124: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-721](https://static.bitcommerz.com/manfarebd/media/md/177894508550780168165_mf_721_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf721)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-721](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf721)
TK. 650

Add To Cart

[![Image 125: 200+ GSM Premium Drop Shoulder Acid Wash T-Shirt | MF-690](https://static.bitcommerz.com/manfarebd/media/md/174421589888171166026_18_mf_690_1.webp)](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-acid-wash-tshirt-mf690)
5.0 | 03

### [200+ GSM Premium Drop Shoulder Acid Wash T-Shirt | MF-690](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-acid-wash-tshirt-mf690)
TK. 650

Add To Cart

[![Image 126: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-716](https://static.bitcommerz.com/manfarebd/media/md/175915135532844357337_mf_716_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf716)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-716](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf716)
TK. 650

Add To Cart

[![Image 127: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-715](https://static.bitcommerz.com/manfarebd/media/md/175915115755054445195_mf_715_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf715)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-715](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf715)
TK. 650

Add To Cart

[![Image 128: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-714](https://static.bitcommerz.com/manfarebd/media/md/175915026637990752796_mf_714_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf714)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-714](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf714)
TK. 650

Add To Cart

[![Image 129: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-713](https://static.bitcommerz.com/manfarebd/media/md/175915011273872324929_mf_713_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf713)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-713](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf713)
TK. 650

Add To Cart

[![Image 130: 200+ GSM Premium Drop Shoulder T-Shirt | MF-676](https://static.bitcommerz.com/manfarebd/media/md/174421523333835522076_24_mf_676_1.webp)](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf676)
4.8 | 30

### [200+ GSM Premium Drop Shoulder T-Shirt | MF-676](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf676)
TK. 650

Add To Cart

[![Image 131: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-710](https://static.bitcommerz.com/manfarebd/media/md/175914972305356397971_mf_710_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf710)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-710](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf710)
TK. 650

Add To Cart

[![Image 132: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-709](https://static.bitcommerz.com/manfarebd/media/md/175914951254493118941_mf_709_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf709)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-709](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf709)
TK. 650

Add To Cart

[![Image 133: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-708](https://static.bitcommerz.com/manfarebd/media/md/175914938965811656371_mf_708_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf708)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-708](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf708)
TK. 650

Add To Cart

[![Image 134: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-706](https://static.bitcommerz.com/manfarebd/media/md/175914903646815505138_mf_706_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf706)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-706](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf706)
TK. 650

Add To Cart

[![Image 135: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-705](https://static.bitcommerz.com/manfarebd/media/md/175914890936845723189_mf_705_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf705)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-705](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf705)
TK. 650

Add To Cart

[![Image 136: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-704](https://static.bitcommerz.com/manfarebd/media/md/175914877895358334156_mf_704_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf704)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-704](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf704)
TK. 650

Add To Cart

[![Image 137: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-703](https://static.bitcommerz.com/manfarebd/media/md/175914849051041567257_mf_703_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf703)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-703](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf703)
TK. 650

Add To Cart

[![Image 138: 200+ GSM Premium Drop Shoulder T-Shirt | MF-688](https://static.bitcommerz.com/manfarebd/media/md/174421836299486973900_13_mf_688_1.webp)](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf688)
0.0 | 0.0

### [200+ GSM Premium Drop Shoulder T-Shirt | MF-688](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf688)
TK. 650

Add To Cart

[![Image 139: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-702](https://static.bitcommerz.com/manfarebd/media/md/175914830560757160273_mf_702_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf702)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-702](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf702)
TK. 650

Add To Cart

[![Image 140: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-701](https://static.bitcommerz.com/manfarebd/media/md/175914763837385998834_mf_701_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf701)
5.0 | 01

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-701](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf701)
TK. 650

Add To Cart

[![Image 141: 200+ GSM Premium Drop Shoulder T-Shirt | MF-677](https://static.bitcommerz.com/manfarebd/media/md/174421712337939371335_15_mf_677_1.webp)](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf677)
4.8 | 35

### [200+ GSM Premium Drop Shoulder T-Shirt | MF-677](https://manfarebd.com/product/200-gsm-premium-drop-shoulder-tshirt-mf677)
TK. 650

Add To Cart

[![Image 142: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-700](https://static.bitcommerz.com/manfarebd/media/md/175914741033146033399_mf_700_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf700)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-700](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf700)
TK. 650

Add To Cart

[![Image 143: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-720](https://static.bitcommerz.com/manfarebd/media/md/175915208258595628550_mf_720_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf720)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-720](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf720)
TK. 650

Add To Cart

[![Image 144: Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-699](https://static.bitcommerz.com/manfarebd/media/md/175914714965893216303_mf_699_2.webp)](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf699)
0.0 | 0.0

### [Acid Wash - Most Trendy Drop Shoulder T Shirt | MF-699](https://manfarebd.com/product/acid-wash-most-trendy-drop-shoulder-t-shirt-mf699)
TK. 650

Add To Cart

# Customer Review

What our customer think about us

![Image 145: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709905054332-manfare_bd-id-13.webp)

![Image 146: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915721198-manfare_bd-id-13.webp)

![Image 147: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915760235-manfare_bd-id-13.webp)

![Image 148: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915810945-manfare_bd-id-13.webp)

![Image 149: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915826659-manfare_bd-id-13.webp)

![Image 150: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915842302-manfare_bd-id-13.webp)

![Image 151: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915855486-manfare_bd-id-13.webp)

![Image 152: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915869230-manfare_bd-id-13.webp)

![Image 153: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915884035-manfare_bd-id-13.webp)

![Image 154: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915900821-manfare_bd-id-13.webp)

![Image 155: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915912920-manfare_bd-id-13.webp)

![Image 156: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915928137-manfare_bd-id-13.webp)

![Image 157: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915940171-manfare_bd-id-13.webp)

![Image 158: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915955169-manfare_bd-id-13.webp)

![Image 159: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915966165-manfare_bd-id-13.webp)

![Image 160: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915984742-manfare_bd-id-13.webp)

![Image 161: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709915996655-manfare_bd-id-13.webp)

![Image 162: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709916012591-manfare_bd-id-13.webp)

![Image 163: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709916024217-manfare_bd-id-13.webp)

![Image 164: customer review](https://static.bitcommerz.com/manfare-bd/media/sm/1709916038949-manfare_bd-id-13.webp)

### Join Our Newsletter To Get Offers

Subscribe to our newsletter and stay updated

Subscribe

[](https://m.me/manfareltd)

![Image 165: manfare logo](https://manfarebd.com/_next/static/media/logo-footer.da33cd5d.png)
+880 9606999695

Worktime: SAT - FRI, 10AM - 11PM

[](https://www.facebook.com/manfareltd)[](https://www.instagram.com/manfare.official/)[](https://api.whatsapp.com/send?phone=8801730642262)[](https://m.me/manfareltd)

#### Information

*   [About](https://manfarebd.com/about)
*   [Privacy Policy](https://manfarebd.com/privacy_policy)
*   [Shipping Policy](https://manfarebd.com/shipping_information)

*   [Return & Exchange Policy](https://manfarebd.com/return_&_exchange_policy)
*   [Payment & Refund policy](https://manfarebd.com/payment_&_refund_policy)
*   [Contact Us](https://manfarebd.com/contact)
*   [Sitemap](https://manfarebd.com/sitemap.xml)

#### Contact Info

*   Bashundhara City Shopping Complex,   
Level-3, Block-D, Shop 45, 46,   
Panthapath, Dhaka.
*   manfarebd@gmail.com
*   info@manfarebd.com
*   09606999695 | 01948-898198   
 01730-642262 | 01845-813237

![Image 166: payment gateway](https://manfarebd.com/_next/static/media/mobile-pay.301ec0cb.png)![Image 167: payment gateway](https://manfarebd.com/_next/static/media/payment-gateway.eb02d190.png)

[Home](https://manfarebd.com/)

Category

Search

Cart

Wishlist

Quick View

![Image 168: product photo](https://manfarebd.com/_next/static/media/product-1.3f2bc68d.png)

![Image 169: product photo](https://manfarebd.com/_next/static/media/product-1.3f2bc68d.png)![Image 170: product photo](https://manfarebd.com/_next/static/media/product-small-2.a6d2920c.png)![Image 171: product photo](https://manfarebd.com/_next/static/media/color-1.de1382d5.png)![Image 172: product photo](https://manfarebd.com/_next/static/media/color-2.056b47d1.png)![Image 173: product photo](https://manfarebd.com/_next/static/media/color-2.056b47d1.png)

## Elite Quality Embroideried Panjabi MM-70

TK. 450 TK. 550

4.6| 25 Reviews

* * *

SIZE:

M

L

XL

XXL

COLOR:

Black

![Image 174: product photo](https://manfarebd.com/_next/static/media/product-1.3f2bc68d.png)![Image 175: product photo](https://manfarebd.com/_next/static/media/product-small-2.a6d2920c.png)![Image 176: product photo](https://manfarebd.com/_next/static/media/color-1.de1382d5.png)![Image 177: product photo](https://manfarebd.com/_next/static/media/color-2.056b47d1.png)![Image 178: product photo](https://manfarebd.com/_next/static/media/color-2.056b47d1.png)

* * *

-+

Add To Cart Buy Now

![Image 179: wishlist icon](https://manfarebd.com/_next/static/media/wishlist-icon.8cdfcb3a.png)
ADD TO WISHLIST

[View Full Product Details](https://manfarebd.com/product)

![Image 180: facebook login](https://manfarebd.com/_next/static/media/fb-logo.08262c5f.png)

LOGIN WITH FACEBOOK

![Image 181: google login](https://manfarebd.com/_next/static/media/google-logo.f7e8e845.png)

LOGIN WITH GOOGLE

LOGIN WITH OTP CODE

SEND CODE

LOGIN

Mobile number 

Password 

- [x] Remember Me LOGIN
Forgot Password?

REGISTER

Mobile number 

Password 

REGISTER
